Hi <?php echo $username; ?>,

<p>We are so glad that you’ve chosen to become an instructor on Studionear.</p>

<p>We believe that you want to learn a form of art and we are here to help you do just that!</p>

<p><u>Your login info:</u><br/>Email: <?php echo $email; ?></p>
<p><a href="<?php echo base_url(); ?>auth/login">STUDIONEAR LOGIN PAGE LINK</a></p>
<p>
    Please feel free to <a href="<?php echo base_url(); ?>">contact us</a> with any questions or suggestions you have. You can send us a message or live chat with our expert on the website. We’re all ears! :D<br/>

</p>


<p>Good Luck!<br/><br/>The Studionear Team</p>


