<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Enrollment_record extends CI_Model {
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

   function insert_enrollment($data)
	{
		$this->db->insert('tbl_enrollment_record', $data);
		return true;
	}

	public function reject_student($data, $StudentID, $CourseID, $BatchID)
    {
        $this->db->where('StudentID',$StudentID);
        $this->db->where('CourseID',$CourseID);
        $this->db->where('BatchID',$BatchID);
		$this->db->update('tbl_enrollment_record', $data);
		return true;
    }

	public function approve_student($data, $StudentID, $CourseID, $BatchID)
    {
        $this->db->where('StudentID',$StudentID);
        $this->db->where('CourseID',$CourseID);
        $this->db->where('BatchID',$BatchID);
		$this->db->update('tbl_enrollment_record', $data);
		return true;
    }
}