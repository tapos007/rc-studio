<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Notification extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    function get_UnReadNotification($email)
    {
        $this->db->where('Email',$email);		
        $this->db->where('Status','Un-Read');
		$query = $this->db->get('$tbl_notification');
        return $query->result();
    }

   public function insert_entry($Email, $Notification)
    {
        $this->db->set('Email',$Email);
        $this->db->set('Notification',$Notification);
        $this->db->set('Status','Un-Read');

        $this->db->insert('tbl_notification');
    }

	public function update_entry($Email, $Notification)
    {
        $this->db->set('Email',$Email);
        $this->db->set('Notification',$Notification);
        $this->db->set('Status','Un-Read');

        $this->db->insert('tbl_notification');
    }
    

}