<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Notification_model extends CI_Model
{
	//private $table_name = 'login_attempts';

	function __construct()
	{
		parent::__construct();

	}
	
	function insert_entry($data)
	{
		$this->db->insert('tbl_notification', $data);
	}
	
	function update_entry($data, $email, $notification, $datetime)
	{
		$this->db->where('Email',$email);		
        $this->db->where('Notification',$notification);
        $this->db->where('DateTime',$datetime);
		$this->db->update('tbl_notification', $data);
	}
	
	function get_UnReadNotification($email)
    {
        $this->db->where('Email',$email);		
        $this->db->where('Status','Un-Read');
		$this->db->order_by("ID", "desc"); 
		$query = $this->db->get('tbl_notification');
        return $query->result();
    }
	
	function get_user_email($id)
	{	
		$this->db->select('email');
		$this->db->where('id',$id);
		$query = $this->db->get('users');
		return $query->result();
	}
	
}