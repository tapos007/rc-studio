<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Transaction extends CI_Model
{
	//private $table_name = 'login_attempts';

	function __construct()
	{
		parent::__construct();

	}
	
	function insert_entry($data, $notificationStu, $notificationTea)
	{
		$this->db->insert('tbl_transaction', $data);
		$this->db->insert('tbl_notification', $notificationStu);
		$this->db->insert('tbl_notification', $notificationTea);
		return true;
	}	
}