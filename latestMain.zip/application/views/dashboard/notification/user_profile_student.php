<?php
$this->lang->load('tank_auth');
$user_email=$this->tank_auth->get_user_email();
$username = $this->tank_auth->get_username();

$data_pic = $this->db->query('SELECT Picture FROM tbl_profile where UserID ="'.$user_email.'"');
foreach($data_pic->result() as $i)   // To get picture
{
	$picture = $i->Picture;
}

//<?php echo base_url();uploads/<?php echo $picture; 
?>

<li class="dropdown">
	<a class="btn account dropdown-toggle" data-toggle="dropdown" href="#">
		<?php if ($picture!= NULL){ ?>
		<div class="avatar"><img src="<?php echo base_url().'public/dashboard/upl/'.$picture; ?>" alt="My Picture" /></div>
		<?php } else { ?>
			<div class="avatar"><img src="<?php echo base_url().'public/dashboard/upl/student.jpg' ?>" alt="My Picture" /></div>
		<?php } ?>
		<div class="user">
		
		<span class="hello"><?php echo $username; ?></span>
		</div>
	</a>
	<ul class="dropdown-menu">
		<li class="dropdown-menu-title">
			
		</li>
		
		<li><a href="<?php echo site_url('student/edit_password');?>"><i class="icon-key"></i>Change Password</a></li>
		<li><a href="<?php echo base_url('auth/logout');?>"><i class="icon-off"></i> Logout</a></li>
	</ul>
</li>