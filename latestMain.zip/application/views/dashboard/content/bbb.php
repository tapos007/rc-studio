<!-- Change Password -->
<div style="position: absolute; top: 0; left: 0; width: 100%; height: 100%;">
<div style="height:0px" id="divCheckbox" style="visibility: hidden">
	<iframe class="" type="text/html"  width="0%" height="0%" src="<?php echo $bbb_link_create; ?>" allowfullscreen frameborder="0">
	</iframe>	
</div>
	<iframe class="" type="text/html"  width="100%" height="100%" src="<?php echo $bbb_link; ?>" allowfullscreen frameborder="0">
	</iframe>	
</div>