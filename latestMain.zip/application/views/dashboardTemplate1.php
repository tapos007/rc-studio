<!DOCTYPE html>
<html lang="en">
    <head>
        <!-- start: Meta -->
        <meta charset="utf-8">
        <title>Official Site of Studio Near www.studionear.com</title>
        <meta name="description" content="Studio Near" />
        <meta name="author" content="Mohammad Arif Hossain" />
        <meta name="keyword" content="Studio Near, Guitar, Piano" />
        <!-- end: Meta -->
        <!-- start: Mobile Specific -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- end: Mobile Specific -->
        <!-- start: CSS -->
        <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/css/style.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>assets/css/retina.min.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url(); ?>latestMain/css/custom_style.css" type="text/css">
        <!-- end: CSS -->
        <!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
        <!--[if lt IE 9]>
                <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
                <script src="assets/js/respond.min.js"></script>
                <script src="assets/css/ie6-8.css"></script>
        <![endif]-->
        <!-- start: Favicon and Touch Icons -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="57x57" href="assets/ico/apple-touch-icon-57-precomposed.png">
        <link rel="shortcut icon" href="assets/ico/favicon.png">
        <!-- end: Favicon and Touch Icons -->
        <!-- start: JavaScript-->
        <!--[if !IE]>-->
        <script src="assets/js/jquery-2.1.0.min.js"></script>
        <!--<![endif]-->
        <!--[if IE]>
                <script src="assets/js/jquery-1.11.0.min.js"></script>
        <![endif]-->
        <!--[if !IE]>-->
        <script type="text/javascript">
            window.jQuery || document.write("<script src='<?php echo base_url(); ?>assets/js/jquery-2.1.0.min.js'>" + "<" + "/script>");
        </script>
        <!--<![endif]-->
        <!--[if IE]>
                <script type="text/javascript">
                window.jQuery || document.write("<script src='<?php echo base_url(); ?>assets/js/jquery-1.11.0.min.js'>"+"<"+"/script>");
                </script>
        <![endif]-->
        <script src="<?php echo base_url(); ?>assets/js/jquery-migrate-1.2.1.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
        <!-- page scripts -->
        <script src="<?php echo base_url(); ?>assets/js/jquery-ui-1.10.3.custom.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.ui.touch-punch.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.sparkline.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/fullcalendar.min.js"></script>
        <!--[if lte IE 8]><script language="javascript" type="text/javascript" src="<?php echo base_url(); ?>assets/js/excanvas.min.js"></script><![endif]-->
        <script src="<?php echo base_url(); ?>assets/js/jquery.flot.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.flot.pie.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.flot.stack.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.flot.resize.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.flot.time.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.autosize.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.placeholder.min.js"></script>
        <!-- theme scripts -->
        
        <!-- inline scripts related to this page -->
        <script src="<?php echo base_url(); ?>assets/js/custom.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/core.min.js"></script>
        <!-- end: JavaScript-->
    </head>
    <body>
        <!-- start: Header -->
        <header class="navbar">
            <div class="container">
                <button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".sidebar-nav.nav-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a id="main-menu-toggle" class="hidden-xs open"><i class="fa fa-bars"></i></a>		
                <a class="navbar-brand col-lg-2 col-sm-1 col-xs-12" href="<?php echo  base_url(); ?>"><img src="<?php echo base_url(); ?>assets/img/Studio-Near3.png"/></a>
                <!-- start: Header Menu -->
                <div class="nav-no-collapse header-nav">
                    <ul class="nav navbar-nav pull-right">
                        <?php echo $this->load->view('dashboard/notification/notification_dropdown'); ?>                   
                        <?php echo $this->load->view('dashboard/notification/message_ dropdown'); ?>
                        <?php echo $this->load->view($user_profile); ?>
                        <!-- end: User Dropdown -->
                    </ul>
                </div>
                <!-- end: Header Menu -->
            </div>	
        </header>
        <!-- end: Header -->
        <div class="container">
            <div class="row">
                <!-- start: Main Menu -->
                <?php echo $this->load->view($main_menu); ?>
                <!-- end: Main Menu -->
                <!-- start: Content -->
                <div id="content" class="col-lg-10 col-sm-11">
                    <div class="row">
                        <!-- Calender Starts-->
                        <?php echo $this->load->view($main_content); ?>
                        <!-- Calender Ends-->
                        <?php if ($content_right) { ?>
                            <div class="col-lg-3">
                                <?php echo $this->load->view($content_right); ?>
                            </div>
                        <?php } ?>
                    </div><!--/row-->
                </div>
                <!-- end: Content -->
            </div><!--/row-->		
        </div><!--/container-->
        <div class="clearfix"></div>
        <footer>
           <!-- <div class="row">
                <div class="col-sm-5">
                    &copy;  2013-2014  <a href="<?php //echo base_url(); ?>">STUDIO NEAR</a>
                </div>
                <div class="col-sm-7 text-right">
                    Powered by: <a href="http://www.r-cis.com" >Recursion</a>
                </div>
            </div>-->	
            
           
            <div class="row footer-thirdPart">
                <div class="container">
                    <div class="col-lg-6">
                        <ul class="nav nav-pills">
                            <li><a href="<?php echo base_url(); ?>">Home</a></li>
                            <li><a href="" data-toggle="modal" data-target="#aboutUs">About Us</a></li>
                            <li><a href="">News</a></li>
                            <li><a href="<?php echo base_url(); ?>welcome/help">FAQs</a></li>
                            <li><a href="" onclick="return popitup()">Site Terms</a></li>
                            <li><a href="" data-toggle="modal" data-target="#contactus">Contact Us</a></li>
                        </ul>
                        <p style="margin-top:10px; padding-left: 15px;">Copyright © 2014-2015. Studio Near LLC. Designed by: <a href="www.r-cis.com"> RECURSION</a></p>
                    </div>
                    <div class="col-lg-6">
                        <div id="s5_socialicons" 	style="margin-right:85px;" >				
                            <!-- <div id="s5_rss"></div>					
                            <div id="s5_google"></div>					
                            <div id="s5_youtube"></div>	-->				
                            <div id="s5_fb"></div>					
                            <div id="s5_twitter"></div>					

                        </div>
                    </div>
                </div>
            </div> 
            
        </footer>
        
    </body>
</html>