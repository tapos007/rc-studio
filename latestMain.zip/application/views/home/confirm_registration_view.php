<div class="row" style='background-color:white'>
<fieldset style="width:80%; margin-top:100px; border:1px solid #ccc" class="container">
<legend>Welcome to Studionear</legend>
<table class="table table-striped" style>
<tr>
	<td colspan = "1"><img width="150" height="150" src="<?php echo base_url().'public/dashboard/upl/'.$picture; ?>"></td>
	<td colspan = "2">
		Dear <?php echo $this->session->userdata('frist_name')." "; ?> <?php echo $this->session->userdata('lastName'); ?>
		You have successfully registered as <?php echo $this->session->userdata('user_role')."."; ?> Please check your email <?php echo $this->session->userdata('email');  ?>
		for account activation and instructions.
		<br>
		<a href="<?php echo site_url('auth/login'); ?>"> Click here </a> to login.
		<br>
		<a href="<?php echo site_url('welcome'); ?>">Click here </a> to go Home.
		<br>
	</td>
 </tr>
 
  
</table>
<br>
 <br>
 <br>
 <br>
 <br>
 <br>
</fieldset>
</div>