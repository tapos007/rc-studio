<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>StudioNear</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Responsive Minimal Bootstrap Theme">
        <meta name="keywords" content="responsive,minimal,bootstrap,theme">
        <meta name="author" content="">
        <link rel="stylesheet" href="<?php echo base_url(); ?>latestMain/css/bootstrap.css" type="text/css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>latestMain/css/custom_style.css" type="text/css">
        <script src="<?php echo base_url(); ?>latestMain/js/jquery-1.11.0.min.js"></script>
        <script src="<?php echo base_url(); ?>latestMain/js/bootstrap.js"></script>
        <script>
            $(document).ready(function() {
                var windowH = $(window).height();
                var wrapperH = $('#carousel-example-generic').height();
                if (windowH > wrapperH) {
                    $('#carousel-example-generic').css({'height': ($(window).height()) + 'px'});
                    $('.item').css({'height': ($(window).height()) + 'px'});
                    $(".img1").css('height', $(window).height() + 'px');
                    $(".img1").attr('width', windowH);
                }
                $("#re-top").hide();

                $("#re-bottom").click(function() {
                    $("#re-top").toggle(1000, function() {
                        if ($('#re-top').is(':visible')) {
                            $('#navsan').css('margin-top', 96);
                        } else {
                            $('#navsan').css('margin-top', 0);
                        }
                    });
                });
                $(window).scroll(function() {
                    if ($(this).scrollTop() > 135) {
                        $('#re-top').show();
                    } else {
                        $('#re-top').hide();
                    }
                });
            });
        </script>
        <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Lato" />
        <script src="<?php echo base_url(); ?>assets/js/jquery.validate.js" type="text/javascript"></script>
        <script>
            $(document).ready(function() {

                $("#form_login").validate({
                    rules: {
                        login: {
                            required: true,
                            email: true

                        },
                        password: "required"
                    },
                    messages: {
                        login: {
                            required: "Please enter a valid email address or user name",
                            email: "enter valid email"
                        },
                        password: "Please enter your passwords"
                    }
                });


            });

        </script>
        <style>
            label.error{
                font-weight: bold;
                color: red;
            }
            .mydropdown{
                padding: 10px;
            }

            ul.mydropdown li a{

                color: black;
              
                padding-top: 10px;

            }
            ul.mydropdown li a:hover{
                padding-top: 10px;
				
                color: black;
            }
        </style>
    </head>
    <body>
        <?php if ($this->session->flashdata('msg')) { ?>
            <script>
                $(document).ready(function() {
                    $('#system').modal('show');
                });

            </script>
        <?php } ?>
        <div class="modal fade" id="contactus" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Contact Us</h4>
                    </div>
                    <div class="modal-body">
                        <?php
                        $attributes = array('id' => 'frmRegConfirm');
                        echo form_open('welcome/contact_us', $attributes);
                        ?>
                        <div class="form-group">
                            <label for="email_contact">Email</label>
                            <input type="text" class="form-control" name="email_contact" id="contac_subject" />
                        </div>
                        <div class="form-group">
                            <label for="subject_contact">Subject</label>
                            <input type="text" class="form-control" name="subject_contact" id="contac_subject" />
                        </div>
                        <div class="form-group">
                            <label for="description_contact"> Description :</label>
                            <textarea class="form-control" rows="3" name="description_contact"></textarea>
                        </div>

                        <button type="submit" name="regConfirm" id="regConfirm" class="btn btn-primary btn-lg btn-block">Submit</button>
                        <?php echo form_close(); ?>
                    </div>
                    <div class="modal-footer">

                    </div>

                </div>
            </div>
        </div>
        <div class="modal fade" id="aboutUs" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">System generated alert</h4>
                    </div>
                    <div class="modal-body">
                        <p style="font-size : 20px">Living in a city like Portland, Oregon we are blessed with access to a wide variety of educational opportunities in the world of arts.  From dance, to music, to yoga, and so on. . .you name it, we have it.  But we found ourselves thinking about those less fortunate than ourselves, those who don’t have a dance studio on every corner.  We decided to spread our love of the arts by creating a live, online studio space where anyone who has a computer can share their talents or learn something new.

                            We envision a world where teachers and students of the arts community can connect, share and learn.
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="system" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">System generated alert</h4>
                    </div>
                    <div class="modal-body">
                        <?php echo $this->session->flashdata('msg'); ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade bs-example-modal-sm" id="myModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width: 350px">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Login to your account</h4>
                    </div>
                    <div class="modal-body">
                        <?php
                        $attributes = array('id' => 'form_login', 'name' => 'form_login', 'style' => 'height:auto');

                        echo form_open('auth/login', $attributes);
                        ?>
                        <div class="form-group">

                            <label for="login">Email address</label>

                            <input type="text" class="form-control" name="login" id="login"  placeholder="Type Email" />

                        </div>

                        <div class="form-group">

                            <label for="password">Password</label>

                            <input type="password" class="form-control" name="password" id="password" placeholder="Type Password" />

                        </div>

                        <div class="checkbox">

                            <label>

                                <input type="checkbox" name="remember" id="remember" value="1"> Remember me

                            </label>

                        </div>



                        <input type="submit" name="submit" id="loginSubmit" class="btn btn-primary btn-lg btn-block" value="Sign In">
                        </form>
                    </div>
                    <div class="modal-footer">
                        <p><h4><b>Forgot Password?</b></h4></p>


                        <p><a  href="<?php echo base_url(); ?>welcome/forget_password" > Click Here </a> <i> to retrive your password.</i></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade bs-example-modal-sm" id="regModel" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width: 350px">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Sign-Up</h4>
                    </div>
                    <div class="modal-body">
                        <p style="font-size:14px; color:#0C3;">Hello and welcome to STUDIO NEAR! Already have an account?<a href="<?php echo base_url(); ?>welcome/loginUnregistered" style="outline:none"> Sign In</a></p>

                        <?php
                        $attributes = array('id' => 'frmRegConfirm');

                        echo form_open('welcome/step1', $attributes);
                        ?>
                        <div class="form-group">
                            <p>
                                <input name="regType" id="regType" type="radio" value="student" />

                                <span style="font-size:12px; color:#06C">Registration as a student</span>
                            </p>
                            <p>
                                <input name="regType" id="regType" type="radio" value="teacher" />
                                <span style="font-size:12px; color:#06C">Registration as a Teacher</span>
                            </p>
                            <input type="submit" name="regConfirm" id="regConfirm" class="btn btn-primary btn-lg btn-block" value="Sign In">
                            </form>
                        </div>
                        <div class="modal-footer">
                            <p><h4><b>Forgot Password?</b></h4></p>
                            <p><a  href="<?php echo base_url(); ?>welcome/forget_password" > Click Here </a> <i> to retrive your password.</i></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <header>
            <div class="navbar-wrapper">
                <nav class="navbar navbar-fixed-top nav-hight nav-background" role="navigation" id="re-top">              
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav mainmenu">
                                <li><a class="selected" href="<?php echo base_url(); ?>">Home</a></li>
                                <li><a href="<?php echo base_url(); ?>welcome/help">How it work</a></li>
                                <li><a href="<?php echo base_url(); ?>welcome/get_search_data">Classes</a></li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">                   
                                <li>
                                    <?php
                                    $attributes = array('class' => 'navbar-form navbar-left search', 'role' => 'search');
                                    echo form_open('welcome/get_search_data', $attributes);
                                    ?>

                                    <div class="form-group">
                                        <input type="text" name ="keyword"  placeholder="Search instructor/Classes" class="form-control input-lg" >
                                    </div>
                                    <input type="hidden" name="min_range" value="10" />
                                    <input type="hidden" name="max_range" value="2000" />
                                    <input type="hidden" name="category" value="Any" />
                                    <input type="hidden" name="subcategory" value="Any" />
                                    <input type="hidden" name="experience" value="0 and 100" />
                                    <input type="hidden" name="ListingOption" value="Instructor" />
                                    <?php echo form_close(); ?>
                                </li>
                                <li> <a class="btn btn-lg btn-image" href="#">BETA</a></li>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </div>
                </nav>
                <nav class="navbar nav-bg-less" role="navigation" id="navsan">
                    <div class="container">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="#"><img src="<?php echo base_url(); ?>latestMain/images/logo/footerLogo.png"></a>
                        </div>

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                            <ul class="nav navbar-nav navbar-right">
                                <?php
                                $role = '';
                                $picture = '';
                                $username = '';
                                $URL = '';
                                $data_pic = $this->db->query('SELECT p.Picture, u.username, u.role FROM tbl_profile as p INNER JOIN users as u ON p.UserID = u.email where UserID ="' . $this->tank_auth->get_user_email() . '"');
                                foreach ($data_pic->result() as $i) {   // To get picture
                                    $picture = $i->Picture;
                                    $username = $i->username;
                                    $role = $i->role;
                                }
                                if ($this->tank_auth->is_logged_in()) {
                                    if ($role == "teacher")
                                        $URL = 'dashboard/teachers_dashboard';
                                    elseif ($role == "student")
                                        $URL = 'dashboard/students_dashboard';
                                    ?>

                                    <li class="dropdown ">
                                        <a data-toggle="dropdown" class="dropdown-toggle" href="#"> 
                                            <?php if ($picture != NULL) { ?>

                                                <span class="avatar"><img src="<?php echo base_url() . 'public/dashboard/upl/' . $picture; ?>"  alt="My Picture" /></span>
                                            <?php } else { ?>
                                                <span class="avatar"><img src="<?php echo base_url() . 'public/dashboard/upl/teacher.jpg' ?>" alt="My Picture" /></span>
                                            <?php } ?>
                                            <span class="hello"><?php echo $username; ?></span>
                                            <b class="caret"></b>
                                        </a>
                                        <ul class="dropdown-menu mydropdown">

                                            <?php
                                            $email = $this->tank_auth->get_user_email();
                                            $SQLComm = "SELECT role from users WHERE email = '" . $email . "' ";
                                            $transaction = $this->db->query($SQLComm);
                                            foreach ($transaction->result() as $trans) {
                                                $var_role = $trans->role;
                                            }
                                            if ($var_role == 'teacher') {
                                                $dashboard_link = 'dashboard/teachers_dashboard';
                                            }
                                            if ($var_role == 'student') {
                                                $dashboard_link = 'dashboard/students_dashboard';
                                            }
                                            ?>
                                            <li><a href="<?php echo base_url($dashboard_link); ?>"><i class="icon-off"></i>Dashboard</a></li>

                                            <li>
                                                <a href="<?php echo site_url($role . '/edit_password'); ?>">
                                                    <i class="icon-key"></i>Change Password</a>
                                            </li>
                                            <li><a href="<?php echo base_url('auth/logout'); ?>"><i class="icon-off"></i> Logout</a></li>
                                        </ul>
                                    </li>
                                <?php } else { ?>
                                    <li><a href="#" data-toggle="modal" data-target="#myModal">Login</a></li>
                                    <li><a href="#" data-toggle="modal" data-target="#regModel">Join</a></li>

                                <?php } ?>
                                <li><a href="#" id="re-bottom">Menu <span class="glyphicon glyphicon-align-justify"></span></a></li>

                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </div><!-- /.container-fluid -->
                </nav>
            </div>
        </header>    

        <!-- old code start point -->     

        <div style="margin-top: 100px;">
            <div class="container">
                <?php
                if (isset($content)) {
                    $this->load->view($content);
                }
                ?>
            </div>
        </div>

        <section>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h4><strong>ABOUT US</strong></h4>
                                </div>
                                <div class="col-lg-12">
                                    <img class="center-block" src="<?php echo base_url(); ?>latestMain/images/book.png" alt="img1">                            
                                    <p>Living in a city like Portland, Oregon we are blessed with access to a wide variety of educational opportunities in the world of arts. From dance, to ... </p>
                                    <div class="centered"><p> <a class="btn btn-lg btn-image" href="#">Learn More</a></p></div>

                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h4><strong>SHARE YOUR ART</strong></h4>
                                </div>
                                <div class="col-lg-12">
                                    <img class="center-block" src="<?php echo base_url(); ?>latestMain/images/book.png" alt="img1">                            
                                    <p>For those artistic experts who want to share what they know. List your classes, decide on a fee, and start teaching students around the country. We keep a ... </p>
                                    <div class="centered"><p> <a class="btn btn-lg btn-image" href="#">Learn More</a></p></div>                              
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4">
                        <div class="thumbnail">
                            <div class="row">
                                <div class="col-lg-12">
                                    <h4><strong>LEARN TO</strong> xxxx</h4>
                                </div>
                                <div class="col-lg-12">
                                    <img class="center-block" src="<?php echo base_url(); ?>latestMain/images/book.png" alt="img1">                            
                                    <p>dance the tango or any other art form for that matter. All you have to do is search available classes or instructors, sign up for a lesson, and enter “the ... </p>
                                    <div class="centered"><p> <a class="btn btn-lg btn-image" href="#">Learn More</a></p></div>                              
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>

        <footer>
            <div class="row footer-firstPart">
                <div class="container">
                    <div class="col-lg-12">
                        <h1>Get involved today and make someones life better! </h1>
                        <div class=" centered"><a data-toggle="modal" data-target="#contactus" class="btn btn-lg footer-firstPart-btn">CONTACT US</a></div>
                    </div>
                </div>
            </div>
            <div class="row footer-SecondPart">
                <div class="container">
                    <div class="col-lg-3 col-md-6 col-xs-6">
                        <img src="<?php echo base_url(); ?>latestMain/images/logo/footerLogo.png">
                    </div>
                    <div class="col-lg-2 col-md-6 col-xs-6">
                        <h5>Contact Us</h5>
                        <p><a href="#">help@studionear.com</a></p>
                    </div>
                    <div class="col-lg-2 col-md-6 col-xs-6">
                        <h5>Learn More ...</h5>
                        <p><a href="#">Learn More</p>
                        <p><a href="#">How IT Works</a></p>
                        <p><a href="#" data-toggle="modal" data-target="#aboutUs">About Us</a></p>
                    </div>
                    <div class="col-lg-2 col-md-6 col-xs-6">
                        <h5>Get Started</h5>
                        <p> <a href="" data-toggle="modal" data-target="#myLogin" >Login</a></p>
                        <p><a href="" data-toggle="modal" data-target="#regConfirm">Join</a></p>
                    </div>
                    <div class="col-lg-2 col-md-6 col-xs-6">
                        <h5>Stay Updated</h5>
                        <p>Stay Updated</p>
                    </div>
                </div>
            </div> 
            <div class="row footer-thirdPart">
                <div class="container">
                    <div class="col-lg-6">
                        <ul class="nav nav-pills">
                            <li><a href="<?php echo base_url(); ?>">Home</a></li>
                            <li><a href="" data-toggle="modal" data-target="#aboutUs">About Us</a></li>
                            <li><a href="">News</a></li>
                            <li><a href="<?php echo base_url(); ?>welcome/help">FAQs</a></li>
                            <li><a href="" onclick="return popitup()">Site Terms</a></li>
                            <li><a href="" data-toggle="modal" data-target="#contactus">Contact Us</a></li>
                        </ul>
                        <p style="margin-top:10px; padding-left: 15px;">Copyright © 2014-2015. Studio Near LLC. Designed by: <a href="www.r-cis.com"> RECURSION</a></p>
                    </div>
                    <div class="col-lg-6">
                        <div id="s5_socialicons" 	style="margin-right:85px;" >				
                            <!-- <div id="s5_rss"></div>					
                            <div id="s5_google"></div>					
                            <div id="s5_youtube"></div>	-->				
                            <div id="s5_fb"></div>					
                            <div id="s5_twitter"></div>					

                        </div>
                    </div>
                </div>
            </div>      
        </footer>


    </body>
</html>
