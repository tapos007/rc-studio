<!DOCTYPE html>
<html lang="en">
<head>
<!-- start: Meta -->
	<meta charset="utf-8" />
	<title>Official Site of Studio Near www.studionear.com</title>
	<meta name="description" content="Studio Near" />
	<meta name="author" content="Mohammad Arif Hossain" />
	<meta name="keyword" content="Studio Near, Guitar, Piano" />
	<!-- end: Meta -->
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<!-- end: Mobile Specific -->
	<!-- start: CSS -->
    <link rel="stylesheet" href="<?php echo base_url(); ?>latestMain/css/custom_style.css" type="text/css">
	<link href="<?php echo base_url();?>public/dashboard/css/bootstrap.min.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>public/dashboard/css/bootstrap-responsive.min.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>public/dashboard/css/style.min.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>public/dashboard/css/style-responsive.min.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>public/dashboard/css/retina.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>public/dashboard/css/dscountdown.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>public/dashboard/css/mycss.css" rel="stylesheet" /> 
	<link href="<?php echo base_url();?>public/dashboard/css/bootstrap-datetimepicker.min.css" rel="stylesheet" />
	<link href="<?php echo base_url();?>public/dashboard/css/pagination.css" rel="stylesheet" type="text/css" > 
	<link href="<?php echo base_url();?>public/dashboard/css/bootstrap-timepicker.css" rel="stylesheet" type="text/css" >
	<!-- end: CSS -->
	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<link id="ie-style" href="css/ie.css" rel="stylesheet">
	<![endif]-->
	<!--[if IE 9]>
		<link id="ie9style" href="css/ie9.css" rel="stylesheet">
	<![endif]-->
	<style>
.error{font-size:12px;color:red;}
</style>
	<!-- start: Favicon and Touch Icons -->
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url();?>public/dashboard/ico/apple-touch-icon-144-precomposed.png" />
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url();?>public/dashboard/ico/apple-touch-icon-114-precomposed.png" />
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url();?>public/dashboard/ico/apple-touch-icon-72-precomposed.png" />
	<link rel="apple-touch-icon-precomposed" href="<?php echo base_url();?>public/dashboard/ico/apple-touch-icon-57-precomposed.png" />
	<link rel="shortcut icon" href="<?php echo base_url();?>public/dashboard/ico/favicon.png" />
	<!-- end: Favicon and Touch Icons -->	
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>
<body>
		<!-- start: Header -->
	<div class="navbar">
		<div class="navbar-inner">
			<div class="container-fluid">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".top-nav.nav-collapse,.sidebar-nav.nav-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a id="main-menu-toggle" class="hidden-phone open"><i class="icon-reorder"></i></a>		
				<div class="row-fluid">
				<a class="brand span2" href="<?php echo base_url(); ?>"><span>STUDIO NEAR</span></a>
				</div>		
				<!-- start: Header Menu -->
				<div class="nav-no-collapse header-nav">
					<ul class="nav pull-right">
						<!----start Notification------->
							<?php echo $this->load->view('dashboard/notification/notification_dropdown'); ?>
						<!---- End Notification --->
						<!-- start: Message Dropdown -->
						<?php echo $this->load->view('dashboard/notification/message_ dropdown');?>
						<!-- end: Message Dropdown -->
						<!-- start: User Dropdown -->
						<?php echo $this->load->view($user_profile); ?>
						<!-- end: User Dropdown -->
					</ul>
				</div>
				<!-- end: Header Menu -->
			</div>
		</div>
	</div>
	<!-- start: Header -->
		<div class="container-fluid-full">
			<div class="row-fluid">
				<!-- start: Main Menu -->
				<div id="sidebar-left" class="span2">
					<?php echo $this->load->view($main_menu); ?>
				</div>
				<!-- end: Main Menu -->
				<!-- start: Content -->
				<div id="content" class="span10">
					<div class="row-fluid">
						<!-- Calender Starts-->
						<?php echo $this->load->view($main_content); ?>
						<!-- Calender Ends-->
						<?php if($content_right){ ?>
						<div class="box span4 noMargin" ontablet="span12" ondesktop="span4">
							<!-- Timer Starts -->
							<?php echo $this->load->view($content_right); ?>				
							<!-- Timer Ends -->
						</div>	
						<?php } ?>
					</div>
				</div>
				<!-- end: Content -->
			</div><!--/fluid-row-->
			<div class="modal hide fade" id="myModal">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">×</button>
					<h3>Settings</h3>
				</div>
				<div class="modal-body">
					<p>Here settings can be configured...</p>
				</div>
				<div class="modal-footer">
					<a href="#" class="btn" data-dismiss="modal">Close</a>
					<a href="#" class="btn btn-primary">Save changes</a>
				</div>
			</div>
			<div class="clearfix"></div>
		<footer>
           <!-- <div class="row">
                <div class="col-sm-5">
                    &copy;  2013-2014  <a href="<?php //echo base_url(); ?>">STUDIO NEAR</a>
                </div>
                <div class="col-sm-7 text-right">
                    Powered by: <a href="http://www.r-cis.com" >Recursion</a>
                </div>
            </div>-->	
            
           
            <div class="row footer-thirdPart">
                <div class="container">
                    <div class="col-lg-6">
                        <ul class="nav nav-pills">
                            <li><a href="<?php echo base_url(); ?>">Home</a></li>
                            <li><a href="" data-toggle="modal" data-target="#aboutUs">About Us</a></li>
                            <li><a href="">News</a></li>
                            <li><a href="<?php echo base_url(); ?>welcome/help">FAQs</a></li>
                            <li><a href="" onclick="return popitup()">Site Terms</a></li>
                            <li><a href="" data-toggle="modal" data-target="#contactus">Contact Us</a></li>
                        </ul>
                        <p style="margin-top:10px; padding-left: 15px;">Copyright © 2014-2015. Studio Near LLC. Designed by: <a href="www.r-cis.com"> RECURSION</a></p>
                    </div>
                    <div class="col-lg-6">
                        <div id="s5_socialicons" 	style="margin-right:85px;" >				
                            <!-- <div id="s5_rss"></div>					
                            <div id="s5_google"></div>					
                            <div id="s5_youtube"></div>	-->				
                            <div id="s5_fb"></div>					
                            <div id="s5_twitter"></div>					

                        </div>
                    </div>
                </div>
            </div> 
            
        </footer>
</div><!--/.fluid-container-->		
	<!-- start: JavaScript-->
	<script src="<?php echo base_url();?>public/dashboard/js/jquery-1.10.2.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>public/home/js/jquery.validate.min.js" ></script>
	<script src="<?php echo base_url();?>public/dashboard/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>public/dashboard/js/bootstrap-timepicker.min.js"></script>
	<script src="<?php echo base_url();?>public/dashboard/js/jquery-migrate-1.2.1.min.js"></script>	
	<script src="<?php echo base_url();?>public/dashboard/js/jquery-ui-1.10.3.custom.min.js"></script>	
	<script src="<?php echo base_url();?>public/dashboard/js/jquery.ui.touch-punch.js"></script>	
	<script src="<?php echo base_url();?>public/dashboard/js/modernizr.js"></script>	
	<script src="<?php echo base_url();?>public/dashboard/js/jquery.cookie.js"></script>	
		<script src='<?php echo base_url();?>public/dashboard/js/fullcalendar.min.js'></script>	
		<script src='<?php echo base_url();?>public/dashboard/js/jquery.dataTables.min.js'></script>
		<script src="<?php echo base_url();?>public/dashboard/js/excanvas.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.flot.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.flot.pie.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.flot.stack.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.flot.resize.min.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.flot.time.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.chosen.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.uniform.min.js"></script>		
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.cleditor.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.noty.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.elfinder.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.raty.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.iphone.toggle.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.uploadify-3.1.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.gritter.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.imagesloaded.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.masonry.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.knob.modified.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.sparkline.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/counter.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/raphael.2.1.0.min.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/justgage.1.0.1.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.autosize.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/retina.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.placeholder.min.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/wizard.min.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/core.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/charts.min.js"></script>	
		<script src="<?php echo base_url();?>public/dashboard/js/custom.min.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/bootstrap-datetimepicker.min.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/bootstrap-datetimepicker.pt-BR.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/dscountdown.min.js"></script>
		<script src="<?php echo base_url();?>public/dashboard/js/jquery.quick.pagination.min.js"></script>
		<script src="<?php echo base_url(); ?>public/dashboard/js/html5gallery.js" ></script>
	<!-- end: JavaScript-->
</body>
</html>