<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Test extends CI_Controller {
	
	function __construct()
	{
		parent::__construct();
				$this->load->library('tank_auth');		$this->lang->load('tank_auth');

	}
	
	public function index()
	{			$role_query = $this->db->query('SELECT role FROM users WHERE email = "' .$this->tank_auth->get_user_email(). '"');		$role = $role_query->row();		print_r($role->role);
	}
	
	function test1()
	{
		$this->load->model('email_model');
		$sub = $this->email_model->get_subject_by_id('105');
		
		echo $sub['subject'];
	}
}