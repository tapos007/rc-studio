<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Dashboard extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('form_validation');
        $this->load->library('security');
        $this->load->library('tank_auth');
        $this->lang->load('tank_auth');
        $this->load->model('Myeventestr');
    }
    
    public function index1() {

      
        $email = $this->tank_auth->get_user_email();
        $result = $this->Myeventestr->getAllBatch($email);


        foreach ($result as $key => $value) {

            $mm = $this->generateDate($value);

            $result[$key] = array_merge($result[$key], array('generatedSchedule' => $mm));
            $result[$key] = array_merge($result[$key], array('generatedSchedule' => $mm));
        }

        
        $myError = array();
        foreach ($result as $myvalue){
            foreach ($myvalue['generatedSchedule'] as $aV){
            $myError[] = array('id' => $aV['id'],
			'title' => $aV['title'],
			'start' => $aV['classDate'],
                        'end' => $aV['classDate'],
			'url' => "teacher/view_course/");
            
            }
            
        }
        echo json_encode($myError);
    }
    public function forTestPurpose(){
          $email = $this->tank_auth->get_user_email();
        $result = $this->Myeventestr->getAllBatch($email);


        foreach ($result as $key => $value) {

            $mm = $this->generateDate($value);

            $result[$key] = array_merge($result[$key], array('generatedSchedule' => $mm));
            $result[$key] = array_merge($result[$key], array('generatedSchedule' => $mm));
        }

        
        $myError = array();
        foreach ($result as $myvalue){
            foreach ($myvalue['generatedSchedule'] as $aV){
            $myError[] = $aV;
            
            }
            
        }
        echo json_encode($myError);
    }

    private function generateDate($value) {

        $totalSchedule = $this->Myeventestr->GenerateEvent($value['BatchID']);
        $courseInfo = array();
        $m = strtotime($value['StartDate']);
        $n = strtotime($value['EndDate']);
        $check_date = $m; // '2010-02-27';
        $end_date = $n; // '2010-03-24';
        $nowTimes = $value;

        $coursedayList = array();


        while ($check_date <= $end_date) {

            $nowDays = date('l', $check_date);
            foreach ($totalSchedule as $aSchedule) {
                $atime = $aSchedule['StartTime'];
                if ($nowDays == $aSchedule['Day']) {

                    //$ccc = "Course Name:" . $value['CourseName'] . " Start form:" . $atime . " and End At" . $aSchedule['EndTime'];
                    $ccc =  $value['CourseName'];
                    $coursedayList[] = array('id' => $value['CourseID'], 'start' => $atime, 'title' => $ccc, "classDate" => date("Y-m-d", $check_date), "Start_time" => $aSchedule['StartTime'], "EndTime" => $aSchedule['EndTime'], "myday" => $nowDays);
                }
            }
            //    $courseInfo[] = array("classDate"=>date("Y-m-d", $check_date),"Start_time"=>,"EndTime","myday")


            $check_date += 86400;
        }
        return $coursedayList;
    }
    
    public function teachers_dashboard() {
        if ($this->tank_auth->is_logged_in()) {
           
            
            $data['user_profile'] = 'dashboard/notification/user_profile_teacher';
            $data['main_content'] = 'dashboard/content/calender';
            $data['content_right'] = 'dashboard/content/timer';
            $this->lang->load('tank_auth');
            $email = $this->tank_auth->get_user_email();
            $SQLComm = "SELECT role from users WHERE email = '" . $email . "' ";
            $transaction = $this->db->query($SQLComm);
            foreach ($transaction->result() as $trans) {
                $var_role = $trans->role;
            }
            if ($var_role == "teacher"): $data['main_menu'] = 'dashboard/menu/main_ menu_teacher1';
            else: $data['main_menu'] = 'dashboard/menu/main_ menu_student';
            endif;
            $this->load->view('dashboardTemplate1', $data);
        }
    }
    public function students_dashboard() {
        if ($this->tank_auth->is_logged_in()) {
            $data['user_profile'] = 'dashboard/notification/user_profile_student';
            $data['main_content'] = 'dashboard/content/calender';
            $data['content_right'] = 'dashboard/content/timer';
            $this->lang->load('tank_auth');
            $email = $this->tank_auth->get_user_email();
            $SQLComm = "SELECT role from users WHERE email = '" . $email . "' ";
            $transaction = $this->db->query($SQLComm);
            foreach ($transaction->result() as $trans) {
                $var_role = $trans->role;
            }
            if ($var_role == "teacher"): $data['main_menu'] = 'dashboard/menu/main_ menu_teacher1';
            else: $data['main_menu'] = 'dashboard/menu/main_ menu_student';
            endif;
            $this->load->view('dashboardTemplate1', $data);
        }
    }
}
