Hi <?php echo $username; ?>,

<p>We are so glad that you’ve chosen to become an instructor on Studionear.</p>

<p>We believe that you have decided to become a part of Studionear because you have a knack for 
art and you want to share it with the world while earning a few bucks. And we are here to help you do just that!</p>

<p><u>Your login info:</u><br/>Email: <?php echo $email; ?></p>
<p><a href="<?php echo base_url();?>auth/login">STUDIONEAR LOGIN PAGE LINK</a></p>
<p><u><span style="color:red">IMPORTANT</span></u><br/>
Please make sure to complete your profile. Here’s what you can do to improve your chances of 
showing up in search results and encourage potential students to sign up for classes you have to offer:<br/>
<ul>
	<li>Add a brief description about yourself</li>
	<li>Enter your education and experience</li>
	<li>Include links to your video </li>
	<li> Setup search preferences and keywords in your profile. For e.g. If you teach salsa dance, you can enter the keyword “Salsa”, or select Salsa in the Set Preference page in </li>
</ul>
</p>

<p>Please feel free to <a href="<?php echo base_url();?>"contact us</a> with any questions or suggestions you have. 
You can send us a message or live chat with our expert on the website. We’re all ears! :D
</p>
<p>Good Luck!<br/><br/>The Studionear Team</p>


