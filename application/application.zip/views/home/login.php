<div style="padding-top:100px">
	<div class="row">
		<div class="col-md-4 col-md-offset-3">

		<?php 
			$attributes =  array('class' => 'form-horizontal', 'role' => 'form', 'id'=>'login');
			echo form_open_multipart('auth/login', $attributes);
		?>
	
		<fieldset>	
			<div class="form-group">
				<label for="login" class="col-sm-2 col-lg-4 control-label" >Email</label>
					<div class="col-sm-10 col-lg-8">
						<input type="text" name="login" id="login" class="form-control" />								
					</div>
				</div>
				<div class="form-group">
				<label for="password" class="col-sm-2 col-lg-4 control-label">Password</label>
					<div class="col-sm-10 col-lg-8">
						<input type="password" name="password" id="password" class="form-control" />
					</div>
				</div>
				<div class="form-group">
				<label for="remember" class="col-sm-2 col-lg-4 control-label">Remember Me</label>
					<div class="col-sm-10 col-lg-8 ">
						<input type="checkbox"  id='remember' name="remember"  />							
					</div>
				</div>
				<div class="form-group">
				<label for="remember" class="col-sm-2 col-lg-4 control-label"></label>
					<div class="col-sm-10 col-lg-8 ">
						<a href="<?php echo site_url('welcome/forget_password'); ?>">Forget Password</a> 							
					</div>
				</div>
				<div class="form-group">
				<div class="col-sm-2 col-lg-4"></div>
				<div class="col-sm-10 col-lg-12 ">
					<div class="center-block text-center" style="">
						<input type="submit" name="next" value="Login" class="btn btn-success" />
						<input type="submit" name="next" value="Cancel" class="btn btn-danger" />
					</div>
				</div>
			</div>
		</fieldset>
	<?php echo form_close(); ?>
	</div>
	</div>
</div>
<script type="text/javascript">
	$("#login").validate({
		rules: {
			login: {
				required: true,
				email: true
			},
			password: {
				required: true,
				minlength: 5
			}		
		},
		messages: {
			login: "Please enter a valid email address",
			password: {
				required: "Please provide a password",
				minlength: "Your password must be at least 5 characters long"
			}
		},
		highlight: function(element) {
    		$(element).closest('.control-group').removeClass('success').addClass('error');
 		 },
 		 success: function(element) {
   			 element
   	 		.text('OK!').addClass('valid')
    		.closest('.control-group').removeClass('error').addClass('success');
  		}
	});
</script>




	