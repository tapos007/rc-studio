<style>
input[type=text] {
	color:#000 !important;
}
</style>
<script>
$(function(){
	$('#creditCard').change(function () {
	   if ($('input#creditCard').is(':checked')) {
		  $("input#payPal").prop('checked', false);
		  $("#cardMenu").removeClass('hide');
		   $('#card_info').removeClass('hide');
		    $("#paypal_submit").addClass('hide');
			$('#submit').removeClass('hide');
		   
		}else{
			$("#card_info").addClass('hide');
			
		}
	});
		
	$('#payPal').change(function () {
		   if ($('input#payPal').is(':checked')) {
			   $("#card_info").removeClass('hide');
			   $("#cardMenu").addClass('hide');
			   $("input#creditCard").prop('checked', false);
			   $("#submit").addClass('hide');
			   $("#new_profile").addClass('hide');
			$('#paypal_submit').removeClass('hide');
			}else {
				 $("#card_info").addClass('hide');
				  $("#cardMenu").removeClass('hide');
			}
 	});
	
	
	$('#cardProfile').change(function () {
		var check = $('#cardProfile').val();
		
		
		
	   if (check == 'New') {
		 
		   $('#new_profile').removeClass('hide');
		   
		}else{
			$("#new_profile").addClass('hide');
			
		}
	});
	
	
});
</script>
<?php 

		

		$this->lang->load('tank_auth');

		$email=$this->tank_auth->get_user_email();

		

	?>
<?php 

		//Get TimeZone and DayLightSaving

		$email = $this->tank_auth->get_user_email();

		$TimeZone = $this->db->query('SELECT TimeZone, DayLightSaving FROM tbl_profile where UserID ="'.$email.'"'); 

		foreach($TimeZone->result()  as $TimeZ){

			$TimeZone = $TimeZ->TimeZone;

			$DayLightSaving = $TimeZ->DayLightSaving;

		}		

		//End TimeZone 

	?>
<?php if($this->session->flashdata('msg')){ ?>
<div class="alert alert-error">
  <button type="button" class="close" data-dismiss="alert">×</button>
  <strong>Warning ! </strong><?php echo $this->session->flashdata('msg'); ?> </div>
<?php } ?>

<!-- Course History and Feedback -->

<div class="col-lg-12">
  
  <div class="box">
    <div class="box-header">
      <h2><i class="fa fa-edit"></i>Payment Information</h2>
      <div class="box-icon"> <a href="form-elements.html#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a> <a href="form-elements.html#" class="btn-close"><i class="fa fa-times"></i></a> </div>
    </div>
    
    <div class="box-content">
    
    <div class="row" style="padding-left:20px;">
    <input type="checkbox" name="creditCard" id="creditCard" value="creditCard" />
    Credit Card
    <input type="checkbox" name="payPal" id="payPal" value="payPal" />
    Paypal </div>
      <div id="card_info" class="hide">
        <?php 
					$attributes = array('class' => 'form-horizontal', 'role' => 'form', 'id'=>'my_profile');
					echo form_open('student/save_payment_info', $attributes);
				?>
        <div class="row" id="cardMenu">
          <div class="form-group">
            <label for="card_type" class="col-sm-4 control-label">Select or create a payment profile:</label>
            <div class="col-sm-4">
              <select name="cardProfile" id="cardProfile" class="form-control" >
                <option value="">--</option>
                <option value="New">New</option>
                <?php
				$QueryRes =  $this->db->query('SELECT distinct(`acct`) FROM `tbl_paypal_transaction_detail` WHERE `student_id`="'. $this->tank_auth->get_user_email().'"');
				if ($QueryRes->num_rows() > 0){
					foreach($QueryRes->result() as $CardDetail){					
						echo '<option value="'.$CardDetail->acct.'">Card Ending '.substr($CardDetail->acct,-4,4).'</option>';
					}
				}
				?>
              </select>
            </div>
          </div>
        </div>
        <div id="new_profile" class="row hide">
          <div class="col-lg-6">
            <div class="form-group">
              <label for="card_type" class="col-sm-4 control-label">Title</label>
              <div class="col-sm-8">
                <select name="title" id="title" class="form-control" >
                  <option value="">--</option>
                  <option value="Mr.">Mr.</option>
                  <option value="Mrs.">Mrs.</option>
                  <option value="Miss">Miss</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="frist_name" class="col-sm-4 control-label">First Name</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="frist_name" name="frist_name" placeholder="First name..">
              </div>
            </div>
            <div class="form-group">
              <label for="last_name" class="col-sm-4 control-label">Last Name</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Last name..">
              </div>
            </div>
            <div class="form-group">
              <label for="address" class="col-sm-4 control-label">Address</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="address" name="address" placeholder="Address ..">
              </div>
            </div>
            <div class="form-group">
              <label for="city" class="col-sm-4 control-label">City</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="city" name="city" placeholder="City ..">
              </div>
            </div>
            <div class="form-group">
              <label for="state" class="col-sm-4 control-label">State/Province</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="state" name="state" placeholder="State/Province..">
              </div>
            </div>
            <div class="form-group">
              <label for="zip" class="col-sm-4 control-label">Zip</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="zip" name="zip" placeholder="Zip..">
              </div>
            </div>
            <div class="form-group">
              <label for="telephone" class="col-sm-4 control-label">Telephone</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="telephone" name="telephone" placeholder="Telephone..">
              </div>
            </div>
            <div class="form-group">
              <label for="country" class="col-sm-4 control-label">Country</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="country" name="country" placeholder="Country ..">
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="form-group">
              <label for="card_type" class="col-sm-4 control-label">Card Type</label>
              <div class="col-sm-8">
                <select name="card_type" id="card_type" class="form-control" >
                  <option value="">Select Card Type</option>
                  <option value="Visa">Visa</option>
                  <option value="MasterCard">Master Card</option>
                  <option value="Amex">American Express</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label for="card_no" class="col-sm-4 control-label">Card No</label>
              <div class="col-sm-8">
                <input type="text" class="form-control" id="card_no" name="card_no" placeholder="Card No..">
              </div>
            </div>
            <div class="form-group">
              <label for="exp_month" class="col-sm-4 control-label">Expairy Date</label>
              <div class="col-sm-4">
                <select name="exp_month" id="exp_month" class="form-control" >
                  <option value="">--Month--</option>
                  <option value="01">January</option>
                  <option value="02">February</option>
                  <option value="03">March</option>
                  <option value="04">April</option>
                  <option value="05">May</option>
                  <option value="06">June</option>
                  <option value="07">July</option>
                  <option value="08">August</option>
                  <option value="09">September</option>
                  <option value="10">October</option>
                  <option value="11">November</option>
                  <option value="12">December</option>
                </select>
              </div>
              <div class="col-sm-4">
                <select name="exp_year" id="exp_year" class="form-control" >
                  <option value="">--Year--</option>
                  <?php 
										$year =  date("Y", now());
										for($i=0; $i<=10; $i++){
										$a = $year + 1;
										$year = $a;
									?>
                  <option value ="<?php echo $a; ?>" ><?php echo $a; ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-4 control-label" for="cvv">Cvv</label>
              <div class="col-sm-8">
                <input type="text" name="cvv" id="cvv" class="form-control" placeholder="Cvv..">
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div  class="checkbox" style="padding:20px 60px">
            <label  for="paypal_check">
              <input type="checkbox" name="paypal_check" id="paypal_check"  />
              I have fully read, understand, and agree to the Terms and Conditions and Privacy Policy.  By clicking on this box and submitting my credit card information, I hereby represent that I am either (1) the user of the service and at least 18 years of age, or (2) the parent or legal guardian of the user of the service, who is a minor, and consent to any and all charges incurred by my child while using this service. </label>
          </div>
          <div class="form-group pull-right">
            <input type="hidden" name="courseID" value="<?php echo $courseID; ?>" />
            <input type="hidden" name="batchID" value="<?php echo $batchID; ?>" />
            <div class="col-sm-8" style="float:left !important;"> 
              <!--<input type="submit" name="submit" id="submit" class="from-control" placeholder="Cvv.." value="Submit"   /> -->
              <button type="submit" name="submit" class="btn btn-success" id="submit">Checkout </button>
              <!-- INFO: The post URL "checkout.php" is invoked when clicked on "Pay with PayPal" button.-->
              </div>
			  <form action='checkout.php' METHOD='POST'>
                <input type='image' name='paypal_submit' id='paypal_submit'  src='https://www.paypal.com/en_US/i/btn/btn_dg_pay_w_paypal.gif' border='0' align='top' alt='Pay with PayPal'/>
              </form>
          </div>
        </div>
      </div>
    </div>
    </form>
</div>
</div>
<!--/col--> 

<!-- Add Digital goods in-context experience. Ensure that this script is added before the closing of html body tag --> 

<script src='https://www.paypalobjects.com/js/external/dg.js' type='text/javascript'></script> 
<script>

	var dg = new PAYPAL.apps.DGFlow(
	{
		trigger: 'paypal_submit',
		expType: 'instant'
		 //PayPal will decide the experience type for the buyer based on his/her 'Remember me on your computer' option.
	});

</script>