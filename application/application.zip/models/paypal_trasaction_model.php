<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Paypal_trasaction_model extends CI_Model
{
	//private $table_name = 'login_attempts';

	function __construct()
	{
		parent::__construct();

	}
	
	function insert_entry($data)
	{
		$this->db->insert('tbl_paypal_transaction_detail', $data);
	}
	function insert_auth_capture($data)	{		$this->db->insert('tbl_paypal_auth_capture_detail', $data);	}
	
}