<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Rating_model extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
   

   public function insert_rating($RatingData)
    {
		if($this->db->insert('tbl_rating', $RatingData))		{			return true;		}else{			return false;		}
    }

   public function update_rating($RatingData,$CourseID, $BatchID,$StudentID)
    {
        $this->db->where('BatchID',$BatchID);
        $this->db->where('CourseID',$CourseID);
        $this->db->where('StudentID',$StudentID);
		$this->db->update('tbl_rating', $RatingData);
		return TRUE;
    }  public function get_rating_course($CourseID)    {        $this->db->where('BatchID',$BatchID);		$this->db->get('tbl_rating');		return TRUE;    }

	   

}