<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Email_model extends CI_Model
{
	//private $table_name = 'login_attempts';

	function __construct()
	{
		parent::__construct();

	}
	
	function get_body_by_id($code)
	{
		$this->db->select('message');
		$this->db->where('code',$code);
		$query = $this->db->get('tbl_email');
        return $query->row_array();
	}
	
	function get_subject_by_id($code)
	{
		$this->db->select('subject');
		$this->db->where('code',$code);
		$query = $this->db->get('tbl_email');
        return $query->row_array();
	}
}