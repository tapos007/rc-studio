<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Teacher_profile_model extends CI_Model
{
	//private $table_name = 'login_attempts';

	function __construct()
	{
		parent::__construct();

	}
	/*
	function insert_entry($data)
	{
		$this->db->insert('tbl_profile', $data);
	}
	*/
	
	function get_ProfileInformation($email)
    {
        $this->db->where('UserID',$email);
		$query = $this->db->get('tbl_profile');
        return $query;
    }
	
	function get_EducationInformation($email)
    {
        $this->db->where('UserID',$email);
		$query = $this->db->get('tbl_education');
        return $query->result();
    }
	
	function get_RatingInformation($email)
    {
		$this->db->where('TeacherID',$email);
		$query = $this->db->get('tbl_rating');
        return $query->result();
    }
	function get_RatingPointAvg($email)
    {
        $this->db->select_avg('RatingPointTeacher');
		$this->db->where('TeacherID',$email);
		$query = $this->db->get('tbl_rating');
        return $query->result();
    }
	
	function insert_teacher_profile($data)
	{
		$this->db->insert('tbl_profile', $data);
	}
	
	function update_teacher_profile($data, $email)
	{
		$this->db->where('UserID',$email);
		$this->db->update('tbl_profile', $data);
		return TRUE;
	}
	
	function update_next_session_date($data, $batch_id)
	{
		$this->db->where('BatchID',$batch_id);
		if($this->db->update('tbl_batch', $data))		{
			return TRUE;		}else{			return false;		}
	}
	
	function insert_education($data)
	{
		$this->db->insert('tbl_education', $data);
	}
	
	function update_educationData($data, $EducationID)
	{
		$this->db->where('EducationID',$EducationID);
		$this->db->update('tbl_education', $data);
		return TRUE;
	}
	
	
	function insert_experience($data)
	{
		$this->db->insert('tbl_experience', $data);
	}
	
	function update_experienceData($data, $experienceID)
	{
		$this->db->where('ExperienceID',$experienceID);
		$this->db->update('tbl_experience', $data);
		return TRUE;
	}
	
	function update_search_preference($data, $Email)
	{
		$this->db->where('UserID',$Email);
		$this->db->update('tbl_search_preference', $data);
		return TRUE;
	}
	
	function search_pref($SearchPref)
	{
		$this->db->insert('tbl_search_preference', $SearchPref);
	}
}