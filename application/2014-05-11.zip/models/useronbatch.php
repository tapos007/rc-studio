<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Useronbatch extends CI_Model
{
	//private $table_name = 'login_attempts';

	function __construct()
	{
		parent::__construct();

	}
	
	function insert_entry($data, $notification,$notification1)
	{
		if($this->db->insert('tbl_useronbatch', $data)){
		$this->db->insert('tbl_notification', $notification);
		$this->db->insert('tbl_notification', $notification1);		return true;				}else {			return false;		}
	}
	
	function update_entry($useronbatchData, $notificationDataStu, $notificationDataIns, $StudentID, $BatchID )
	{
		$this->db->where('UserID',$StudentID);
        $this->db->where('BatchID',$BatchID);
		$this->db->update('tbl_useronbatch', $useronbatchData);
		
		$this->db->insert('tbl_notification', $notificationDataStu);
		$this->db->insert('tbl_notification', $notificationDataIns);
	}	
}