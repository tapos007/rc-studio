<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


class Create_course_model extends CI_Model
{
	//private $table_name = 'login_attempts';

	function __construct()
	{
		parent::__construct();

	}
	
	function insert_useronbatch($data)
	{
		$this->db->insert('tbl_useronbatch', $data);
		return true;
	}
	
	function insert_course($data)
	{
		$this->db->insert('tbl_course', $data);
		return true;
	}
	
	function insert_batch($data)
	{
		$this->db->insert('tbl_batch', $data);
		return true;
	}
	
	function insert_schedule($data)
	{
		$this->db->insert('tbl_schedule', $data);
		return true;
	}
	
	function get_course($id)
	{
		$this->db->where('CourseID',$id);
		$query = $this->db->get('tbl_course');
        return $query;
	}
	
	function get_batch($id)
	{
		$this->db->where('BatchID',$id);
		$query = $this->db->get('tbl_batch');
        return $query;
	}
	
	function get_schedules($id)
	{
		$this->db->where('BatchID',$id);
		$query = $this->db->get('tbl_schedule');
        return $query;
	}
	
	// Update course data
	function update_course($data, $id)
	{
		$this->db->where('CourseID',$id);
		$this->db->update('tbl_course', $data);
		return true;
	}
	
	function update_batch($data, $id)
	{
		$this->db->where('BatchID',$id);
		$this->db->update('tbl_batch', $data);
		return true;
	}
	
	function update_schedule($data, $id)
	{
		$this->db->where('ScheduleID',$id);
		$this->db->update('tbl_schedule', $data);
		return true;
	}
	//End Update
	
}