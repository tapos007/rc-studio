<div class="span7" ontablet="span12" ondesktop="span7">
	<div class="well">
      <!---This section for panel component-->

      <div class="panel panel-primary">
        

        <div class="panel-body">
          <!--This section for media-->

          <div class="media">
            <a class="pull-left" href="#"><iframe frameborder="0" height="315"
            src="//www.youtube.com/embed/b27uk5edY5M" width="420"></iframe></a>

            <div class="main-body">
              <!-- this section we will add information about the video-->

              <p><strong>Season 1 - Episode 1</strong> The X-Life is an
              American reality television series on VH1 that follows three
              extreme athletes and their wives as they navigate their lives
              with their famous careers.</p>
            </div>
          </div>
        </div>
		
		<div class="panel-body">
          <!--This section for media-->

          <div class="media">
            <a class="pull-left" href="#"><iframe frameborder="0" height="315"
            src="//www.youtube.com/embed/b27uk5edY5M" width="420"></iframe></a>

            <div class="main-body">
              <!-- this section we will add information about the video-->

              <p><strong>Season 1 - Episode 1</strong> The X-Life is an
              American reality television series on VH1 that follows three
              extreme athletes and their wives as they navigate their lives
              with their famous careers.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
</div>